#!/usr/bin/env python3

import rospy
from ros_learning.msg import MotorAngle
from std_msgs.msg import Int32MultiArray
from adafruit_servokit import ServoKit
import board
import busio
import adafruit_ads1x15.ads1115 as ADS
from time import sleep

global fsr_val

fsr_val = 0


if __name__ == "__main__":
    kit = ServoKit(channels=16)
    kit.servo[1].set_pulse_width_range(500, 2400)
    i2c = busio.I2C(board.SCL, board.SDA)
    ads = ADS.ADS1115(i2c)
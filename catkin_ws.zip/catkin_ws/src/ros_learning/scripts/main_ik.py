#!/usr/bin/env python3

from adafruit_servokit import ServoKit
from time import sleep
import board
import busio
import adafruit_ads1x15.ads1115 as ADS
from ik_functions import *

"""
PCA Channel to Servo
1 thumb mcp
2 thumb pipdip
3 index mcp 
4 index pipdip
5 middle mcp
6 middle pipdip
7 ring mcp
8 ring pipdip
9 pinky mcp
10 pinky pipdip
"""

finger1_ik_joint = ik_finger_joint(69.754 ,51.16, 20)

print("Finger joint angles: ", finger1_ik_joint)

finger1_ik_servo = ik_finger_servo(finger1_ik_joint[0], finger1_ik_joint[1], finger1_ik_joint[2])

#print(finger1_ik_servo)
servo_mcp = finger1_ik_servo[0]
servo_pipdip = abs(finger1_ik_servo[1])
print("Finger servo angles")
print(servo_mcp,servo_pipdip)

thumb_ik_joint = ik_thumb_joint(16, 27, 19) # x,y,z in cad (8.7, 15.2,32)
print("thumb joint angles: ",thumb_ik_joint)

thumb_ik_servo = ik_thumb_servo(thumb_ik_joint[0], thumb_ik_joint[1], thumb_ik_joint[2])
print("thumb servo angles: ", thumb_ik_servo)
servo_cmc = thumb_ik_servo[0]
servo_mcpip = thumb_ik_servo[2]

"""

if __name__ == "__main__":

    i2c = busio.I2C(board.SCL, board.SDA)
    ads = ADS.ADS1115(i2c)

    kit = ServoKit(channels=16)
    kit.servo[1].set_pulse_width_range(500, 2400)
    kit.servo[2].set_pulse_width_range(500, 2350)
    kit.servo[3].set_pulse_width_range(500, 2400)
    kit.servo[4].set_pulse_width_range(500, 2400)

    ## home
    print("homing")
    kit.servo[1].angle = 180
    kit.servo[2].angle = 180
    kit.servo[3].angle = 180
    kit.servo[4].angle = 180
    sleep(2)

    ## move
    print("executing move")
    kit.servo[1].angle = 180 - servo_cmc
    sleep(2)
    kit.servo[2].angle = 180 - 55
    #kit.servo[3].angle = 180-servo_mcp
    #kit.servo[4].angle = 180-servo_pipdip
    sleep(5)

    ## home
    print("homing")
    kit.servo[1].angle = 180
    kit.servo[2].angle = 180
    kit.servo[3].angle = 180
    kit.servo[4].angle = 180

"""
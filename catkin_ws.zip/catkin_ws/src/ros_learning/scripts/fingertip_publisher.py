#!/usr/bin/env python3

import rospy 
from std_msgs.msg import String
from time import sleep
import pickle
from ik_functions import *
from ros_learning.msg import Hand
import numpy as np

def fingertip_publish():
    try:
        for i in range(len(fingertip)):
            frame = fingertip[i]

            frame = np.array(frame)
            where_are_NaNs = np.isnan(frame)
            frame[where_are_NaNs] = int(0)

            thumb_pos = [frame[0], frame[1], frame[2]]  # [x,y,z]
            index_pos = [frame[3], frame[4], frame[5], frame[6]-15]  # [x,y,z,g]
            middle_pos = [frame[7], frame[8], frame[9], frame[10]-15]  # [x,y,z,g]
            ring_pos = [frame[11], frame[12], frame[13], frame[14]-15]  # [x,y,z,g]
            pinky_pos = [frame[15], frame[16], frame[17], frame[18]-15]  # [x,y,z,g]

            x1 = thumb_pos[0]
            y1 = thumb_pos[1]
            z1 = thumb_pos[2]

            x2 = index_pos[0]
            y2 = index_pos[1]
            z2 = index_pos[2]
            phi2 = index_pos[3]

            x3 = middle_pos[0]
            y3 = middle_pos[1]
            z3 = middle_pos[2]
            phi3 = middle_pos[3]

            x4 = ring_pos[0]
            y4 = ring_pos[1]
            z4 = ring_pos[2]
            phi4 =ring_pos[3]

            x5 = pinky_pos[0]
            y5 = pinky_pos[1]
            z5 = pinky_pos[2]
            phi5 = pinky_pos[3]

            rospy.loginfo([x1,y1,z1,x2,y2,z2,phi2,x3,y3,z3,phi3,x4,y4,z4,phi4,x5,y5,z5,phi5])
            pub.publish(int(x1),int(y1),int(z1),int(x2),int(y2),int(z2),int(phi2),
                        int(x3),int(y3),int(z3),int(phi3),int(x4),int(y4),int(z4),int(phi4),
                        int(x5),int(y5),int(z5),int(phi5))
            print(i)
            #rospy.loginfo([frame])

            #pub.publish(frame)
            rate.sleep()
            sleep(0.5)

    except KeyboardInterrupt:
        print("Ctrl C pressed.")
        pass

if __name__ == '__main__':

    with open('fingertipArray.txt', 'rb') as f:
        fingertip = pickle.load(f)

    i = 0

    rospy.init_node('fingertip_publisher', anonymous = True)
    pub = rospy.Publisher('ik_motor_angle', Hand, queue_size = 10) # servo_angle topic
    rate = rospy.Rate(10)
    
    while not rospy.is_shutdown():
        try:
            fingertip_publish()
        except rospy.ROSInterruptException:
            pass


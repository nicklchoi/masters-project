#this program generates ROS msg

import csv
import pickle
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from time import sleep
from ik_functions import *

with open('fingertipArray.txt', 'rb') as f:
    fingertip= pickle.load(f)

i = 0

for i in range(len(fingertip)):
    frame = fingertip[i]

# 0-2 thumb
# 3-6 index
# 7-10 middle
# 11-14 ring
# 15 - 18 pinky

#print(frame)

    thumb_pos = [frame[0], frame[1], frame[2]]  # [x,y,z]
    index_pos = [frame[3], frame[4], frame[5], frame[6]-15]  # [x,y,z,g]
    middle_pos = [frame[7], frame[8], frame[9], frame[10]]  # [x,y,z,g]
    ring_pos = [frame[11], frame[12], frame[13], frame[14]]  # [x,y,z,g]
    pinky_pos = [frame[15], frame[16], frame[17], frame[18]]  # [x,y,z,g]

    # x1



    count_index = index_pos.count(0)
    if count_index > 0:
        print("pass. 0 ")
        print()
        #sleep(0.2)
        continue


    thumb_ik_joint = ik_thumb_joint(thumb_pos[0], thumb_pos[1], thumb_pos[2])
    #print("frame: " + str(i) + "     thumb pos: ", thumb_pos)
    #print("thumb ik joint: ", thumb_ik_joint)

    index_ik_joint = ik_finger_joint(index_pos[1], index_pos[2], index_pos[3])


    if index_ik_joint[0] > 90:
        print("pass. > 90")
        print()
        continue

    if index_ik_joint[1] > 0 or index_ik_joint[2] > 0:
        print("pass. > 0")
        print()
        continue

    print("frame: " + str(i) + "     index pos: ", index_pos)
    print("index ik joint: ", index_ik_joint)

    thumb_ik_servo = ik_thumb_servo(thumb_ik_joint[0], thumb_ik_joint[1], thumb_ik_joint[2])
    #print("thumb ik servo: ", thumb_ik_servo)

    index_ik_servo = ik_finger_servo(index_ik_joint[0], index_ik_joint[1], index_ik_joint[2])
    print("index ik servo: ", index_ik_servo)
    print()

    #sleep(0.2)


from math import pi, cos, sin, acos, asin, atan, atan2, sqrt
import numpy as np

def ik_finger_joint(x,z,g): #enter finger tip position [mm] and orientation to return joint angle [deg]
    # joint lengths
    l1 = 37  # mm, joint 1 length
    l2 = 24  # mm, joint 2 length
    l3 = 28  # mm, joint 3 length

    x_e = x
    y_e = z
    phi_e = g*3.14/180

    x_w = x_e - l3 * cos(phi_e)  # x wrist
    y_w = y_e - l3 * sin(phi_e)  # y wrist

    theta2_ik = atan2(-(1 - (((x_w ** 2 + y_w ** 2 - l1 ** 2 - l2 ** 2) / (2 * l1 * l2)) ** 2)) ** (1 / 2),
                      (x_w ** 2 + y_w ** 2 - l1 ** 2 - l2 ** 2) / (2 * l1 * l2))
    theta2_ik_deg = theta2_ik*180/3.14
    #print(theta2_ik * 180 / 3.14)  # deg

    k1 = l1 + l2 * cos(theta2_ik)
    k2 = l2 * sin(theta2_ik)
    theta1_ik = (atan2(y_w, x_w) - atan2(k2, k1))
    theta1_ik_deg = theta1_ik * 180 / 3.14
    #print(theta1_ik * 180 / 3.14)

    theta3_ik = phi_e - theta1_ik - theta2_ik
    theta3_ik_deg = theta3_ik * 180 / 3.14
    #print(theta3_ik * 180 / 3.14)

    return [theta1_ik_deg,theta2_ik_deg,theta3_ik_deg]

def ik_finger_servo(theta_mcp, theta_pip, theta_dip): #convert joint angle to servo angle
    theta_1 = (90-theta_mcp) + 15
    theta_2 = 1/2*theta_pip
    #theta_3 = 1/4.5*theta_dip

    return [theta_1, theta_2]

def ik_thumb_joint(x,y,z):
    l1 = 34
    l2 = 37
    l3 = 33

    d = ((x**2 + y**2))**(1/2) + l1
    print(d)

    theta1_ik = np.arctan2(y,x)
    theta3_ik = np.arctan2(-((1-((((d**2) + (z**2) - (l2**2) - (l3**2))/(2*l2*l3))**2))**(1/2)),((d**2)+(z**2)- (l2**2)-(l3**2))/(2*l2*l3))
    theta2_ik = np.arctan2(z,d) - np.arctan2(l3*np.sin(theta3_ik),l2+(l3*np.cos(theta3_ik)))

    theta1_ik_deg = theta1_ik * 180 / 3.14
    theta2_ik_deg = theta2_ik * 180 / 3.14
    theta3_ik_deg = theta3_ik * 180 / 3.14

    return [theta1_ik_deg,theta2_ik_deg, theta3_ik_deg]

def ik_thumb_joint(x,y,z):
    l1 = 34
    l2 = 37
    l3 = 33

    d = ((x**2 + y**2))**(1/2) + l1
    #print(d)

    theta1_ik = np.arctan2(y,x)
    theta2_ik = 0
    theta3_ik = 0
    theta1_ik_deg = theta1_ik * 180 / 3.14

    #theta3_ik = np.arctan2(-((1-((((d**2) + (z**2) - (l2**2) - (l3**2))/(2*l2*l3))**2))**(1/2)),((d**2)+(z**2)- (l2**2)-(l3**2))/(2*l2*l3))
    #theta2_ik = np.arctan2(z,d) - np.arctan2(l3*np.sin(theta3_ik),l2+(l3*np.cos(theta3_ik)))


    theta2_ik_deg = theta2_ik * 180 / 3.14
    theta3_ik_deg = 90 - (theta3_ik * 180 / 3.14)

    return [theta1_ik_deg,theta2_ik_deg, theta3_ik_deg]

def ik_thumb_servo(theta_cmc, theta_mcp, theta_ip):
    theta_1 = (1/0.9)*theta_cmc
    slack = (2.5411E-20) * theta_1 ** 6 + (0.0000000062099) * theta_1 ** 5 - (0.0000028446) * theta_1 ** 4 + (
        0.00044752) * theta_1 ** 3 - (0.028722) * theta_1 ** 2 + (0.87874) * theta_1 + 10.0119
    theta_2 = (1/3)*theta_mcp + slack
    theta_3 = (1/4.5)*theta_ip + slack

    return [theta_1, theta_2, theta_3]



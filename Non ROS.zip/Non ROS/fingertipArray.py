## this program generates fingertip array (x, y, z gamma) for each frame

import csv
import pickle
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

with open('handkeypoints_vid.txt', 'rb') as f:
    handkeypoints = pickle.load(f)

# finger joint lengths [MOD]
#l1 = 43  # mm, joint 1 length
#l2 = 26  # mm, joint 2 length
#l3 = 30  # mm, joint 3 length

# finger joint lengths [OG]
l1 = 37  # mm, joint 1 length
l2 = 24  # mm, joint 2 length
l3 = 28  # mm, joint 3 length

# thumb joint lengths [mod]
#l1_thumb = 34
#l2_thumb = 37

# thumb joint lengths [og]
l1_thumb = 37
l2_thumb = 33

#handKeypoints = handkeypoints[10:240]
handKeypoints = handkeypoints
shape = np.shape(handKeypoints)
print(type(handKeypoints))

## solve
hand_fingertip = []
x=[]
y=[]
i=0
j=0


for j in range(shape[0]):
    frame = handKeypoints[j]
    #print(frame)
    x = []
    y = []
    fingertips = []
    if frame.count(None) > 1:
        fingertips = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,0,0,0,0]
        hand_fingertip.append(fingertips)
        continue
    for i in range(len(frame)):
        if frame[i] == None:
            break
        if frame.count(None) > 1:
            break
        x=np.append(x, frame[i][0])
        y=np.append(y, frame[i][1])
        i = i + 1

    y_offset = max(y)
    # print(y_offset)

    # altered hand keypoints
    x = 0.8 * x
    y = 0.7 * (-y + y_offset)

    # plot keypoints
    #plt.figure()
    #plt.scatter(x, y)

    # plot thumb
    x_thumb = x[0:5]
    y_thumb = y[0:5]
    #plt.plot(x_thumb, y_thumb)

    # plot index
    x_index = x[0]
    x_index = np.append(x_index, x[5:9])
    y_index = y[0]
    y_index = np.append(y_index, y[5:9])
    #plt.plot(x_index, y_index)

    # plot middle
    x_middle = x[0]
    x_middle = np.append(x_middle, x[9:13])
    y_middle = y[0]
    y_middle = np.append(y_middle, y[9:13])
    #plt.plot(x_middle, y_middle)

    # plot ring
    x_ring = x[0]
    x_ring = np.append(x_ring, x[13:17])
    y_ring = y[0]
    y_ring = np.append(y_ring, y[13:17])
    #plt.plot(x_ring, y_ring)

    # plot pinky
    x_pinky = x[0]
    x_pinky = np.append(x_pinky, x[17:21])
    y_pinky = y[0]
    y_pinky = np.append(y_pinky, y[17:21])
    #plt.plot(x_pinky, y_pinky)

    #plt.title("Hand Keypoint Detection (Scaled)")
    #plt.xlabel("x [pixels]")
    #plt.ylabel("z [pixels]")
    # plt.show()

    # set joints relative to finger origin
    y_thumb_j1 = y_thumb[2] - y_thumb[1]
    y_thumb_j2 = y_thumb[3] - y_thumb[2]

    y_index_j1 = y_index[2] - y_index[1]
    y_index_j2 = y_index[3] - y_index[2]
    y_index_j3 = y_index[4] - y_index[3]

    y_middle_j1 = y_middle[2] - y_middle[1]
    y_middle_j2 = y_middle[3] - y_middle[2]
    y_middle_j3 = y_middle[4] - y_middle[3]

    y_ring_j1 = y_ring[2] - y_ring[1]
    y_ring_j2 = y_ring[3] - y_ring[2]
    y_ring_j3 = y_ring[4] - y_ring[3]

    y_pinky_j1 = y_pinky[2] - y_pinky[1]
    y_pinky_j2 = y_pinky[3] - y_pinky[2]
    y_pinky_j3 = y_pinky[4] - y_pinky[3]

    ## solve thumb fingertip
    theta1_thumb = np.arcsin(y_thumb_j1 / l1)
    x_thumb_j1 = l1_thumb * np.cos(theta1_thumb)

    theta2_thumb = np.arcsin(y_thumb_j2 / l2)
    x_thumb_j2 = x_thumb_j1 + l2_thumb * np.cos(theta2_thumb)

    x_dist_thumb = abs(x_thumb[4] - x_thumb[2])

    thumb_fingertip = [x_dist_thumb, x_thumb_j2, y_thumb[4] - y_thumb[2]]
    thumb_fingertip = list(np.around(np.array(thumb_fingertip), 2))

    thumb_joint = [np.degrees(theta1_thumb), np.degrees(theta2_thumb)]
    thumb_joint = list(np.around(np.array(thumb_joint), 2))

    ##solve index fingertip
    theta1_index = np.arcsin(y_index_j1 / l1)
    x_index_j1 = l1 * np.cos(theta1_index)
    # print(x_index_j1)

    theta2_index = np.arcsin(y_index_j2 / l2)
    x_index_j2 = x_index_j1 + l2 * np.cos(theta2_index)
    # print(x_index_j2)

    theta3_index = np.arcsin(y_index_j3 / l3)
    x_index_j3 = x_index_j2 + l3 * np.cos(theta3_index)
    # print(x_index_j3)

    index_fingertip = [0, x_index_j3, y_index[4] - y_index[1]]
    index_fingertip = list(np.around(np.array(index_fingertip), 2))

    index_joint = [np.degrees(theta1_index), np.degrees(theta2_index), np.degrees(theta3_index)]
    index_joint = list(np.around(np.array(index_joint), 2))

    ##solve middle fingertip
    theta1_middle = np.arcsin(y_middle_j1 / l1)
    x_middle_j1 = l1 * np.cos(theta1_middle)
    # print(x_middle_j1)

    theta2_middle = np.arcsin(y_middle_j2 / l2)
    x_middle_j2 = x_middle_j1 + l2 * np.cos(theta2_middle)
    # print(x_middle_j2)

    theta3_middle = np.arcsin(y_middle_j3 / l3)
    x_middle_j3 = x_middle_j2 + l3 * np.cos(theta3_middle)
    # print(x_middle_j3)

    middle_fingertip = [0, x_middle_j3, y_middle[4] - y_middle[1]]
    middle_fingertip = list(np.around(np.array(middle_fingertip), 2))

    middle_joint = [np.degrees(theta1_middle), np.degrees(theta2_middle), np.degrees(theta3_middle)]
    middle_joint = list(np.around(np.array(middle_joint), 2))

    ##solve ring fingertip
    theta1_ring = np.arcsin(y_ring_j1 / l1)
    x_ring_j1 = l1 * np.cos(theta1_ring)
    # print(x_ring_j1)

    theta2_ring = np.arcsin(y_ring_j2 / l2)
    x_ring_j2 = x_ring_j1 + l2 * np.cos(theta2_ring)
    # print(x_ring_j2)

    theta3_ring = np.arcsin(y_ring_j3 / l3)
    x_ring_j3 = x_ring_j2 + l3 * np.cos(theta3_ring)
    # print(x_ring_j3)

    ring_fingertip = [0, x_ring_j3, y_ring[4] - y_ring[1]]
    ring_fingertip = list(np.around(np.array(ring_fingertip), 2))

    ring_joint = [np.degrees(theta1_ring), np.degrees(theta2_ring), np.degrees(theta3_ring)]
    ring_joint = list(np.around(np.array(ring_joint), 2))

    ##solve pinky fingertip
    theta1_pinky = np.arcsin(y_pinky_j1 / l1)
    x_pinky_j1 = l1 * np.cos(theta1_pinky)
    # print(x_pinky_j1)

    theta2_pinky = np.arcsin(y_pinky_j2 / l2)
    x_pinky_j2 = x_pinky_j1 + l2 * np.cos(theta2_pinky)
    # print(x_ring_j2)

    theta3_pinky = np.arcsin(y_pinky_j3 / l3)
    x_pinky_j3 = x_pinky_j2 + l3 * np.cos(theta3_pinky)
    # print(x_pinky_j3)

    pinky_fingertip = [0, x_pinky_j3, y_pinky[4] - y_pinky[1]]
    pinky_fingertip = list(np.around(np.array(pinky_fingertip), 2))

    pinky_joint = [np.degrees(theta1_pinky), np.degrees(theta2_pinky), np.degrees(theta3_pinky)]
    pinky_joint = list(np.around(np.array(pinky_joint), 2))

    # calculated fingertip positions
    #print("thumb fingertip position: ", thumb_fingertip)
    #print("index fingertip position: ", index_fingertip)
    #print("middle fingertip position: ", middle_fingertip)
    #print("ring fingertip position: ", ring_fingertip)
    #print("pinky fingertip position: ", pinky_fingertip)
    print()

    if x_thumb[3] - x_thumb[2] > 0:
        thumb_fingertip0 = -thumb_fingertip[0]
    else:
        thumb_fingertip0 = thumb_fingertip[0]

    yscale_index = 0.6  # 0.3
    yscale_middle = 0.7  # 0.3
    yscale_ring = 0.6  # 0.3
    yscale_pinky = 0.5  # 0.3
    zscale = 1  # 1.4

    fig = plt.figure(figsize=(8, 8))
    ax = fig.add_subplot(111, projection='3d')
    ax.scatter(-thumb_fingertip0, yscale_index * thumb_fingertip[1], zscale * thumb_fingertip[2], label='thumb')
    ax.scatter(-10, yscale_index * index_fingertip[1], zscale * index_fingertip[2], label='index')
    ax.scatter(-20, yscale_middle * middle_fingertip[1], zscale * middle_fingertip[2], label='middle')
    ax.scatter(-30, yscale_ring * ring_fingertip[1], zscale * ring_fingertip[2], label='ring')
    ax.scatter(-40, yscale_pinky * pinky_fingertip[1], zscale * pinky_fingertip[2], label='pinky')
    ax.set_xlabel('x (finger spacing) [mm]')
    ax.set_ylabel('y (finger reach) [mm]')
    ax.set_zlabel('z (finger height) [mm]')
    ax.legend()
    plt.title("Fingertip positions in 3D")
    #imagename = 'videoTest/ ' + 'testimage' + str(j) + ".png"
    #plt.savefig(imagename)
    #plt.show()

    # calculated joint angles
    """
    print("thumb joint angles: ", thumb_joint)
    print("index joint angles: ", index_joint)
    print("middle joint angles: ", middle_joint)
    print("ring joint angles: ", ring_joint)
    print("pinky joint angles: ", pinky_joint)
    """
    # plt.show()

    thumb_fingertip_pos = [-thumb_fingertip0, yscale_index * thumb_fingertip[1], zscale * thumb_fingertip[2]]
    index_fingertip_pos = [-10, yscale_index * index_fingertip[1], zscale * index_fingertip[2],np.degrees(theta3_index)]
    middle_fingertip_pos = [-20, yscale_middle * middle_fingertip[1], zscale * middle_fingertip[2], np.degrees(theta3_middle)]
    ring_fingertip_pos = [-30, yscale_ring * ring_fingertip[1], zscale * ring_fingertip[2], np.degrees(theta3_ring)]
    pinky_fingertip_pos = [-40, yscale_pinky * pinky_fingertip[1], zscale * pinky_fingertip[2], np.degrees(theta3_ring)]

    fingertips.extend(thumb_fingertip_pos)
    fingertips.extend(index_fingertip_pos)
    fingertips.extend(middle_fingertip_pos)
    fingertips.extend(ring_fingertip_pos)
    fingertips.extend(pinky_fingertip_pos)


    j = j +1

    hand_fingertip.append(fingertips)
    print(np.shape(hand_fingertip))

#print(np.shape(hand_fingertip))
print(hand_fingertip)

#with open ('fingertipArray_og.txt', 'wb') as f:
#    pickle.dump(hand_fingertip,f)
# Runs handkeypoint detection. outputs 2D skeleton,2D plot, 3D fingertip plot
#11/7

import cv2
import time
import numpy as np
import pickle
import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
import pickle

handkeypoints = []
i=0

# finger joint lengths
l1 = 43  # mm, joint 1 length 43
l2 = 26  # mm, joint 2 length 26
l3 = 30  # mm, joint 3 length 30

# thumb joint lengths
l1_thumb = 34 #34
l2_thumb = 37 #37?

protoFile = "hand/pose_deploy.prototxt"
weightsFile = "hand/pose_iter_102000.caffemodel"
nPoints = 22
POSE_PAIRS = [ [0,1],[1,2],[2,3],[3,4],[0,5],[5,6],[6,7],[7,8],[0,9],[9,10],[10,11],[11,12],[0,13],[13,14],[14,15],[15,16],[0,17],[17,18],[18,19],[19,20] ]

threshold = 0.2


#input_source = "asl.mp4"
input_source = "my_hand2.avi"
cap = cv2.VideoCapture(input_source)
#cap = cv2.VideoCapture(0)
hasFrame, frame = cap.read()

frameWidth = frame.shape[1]
frameHeight = frame.shape[0]

aspect_ratio = frameWidth/frameHeight

inHeight = 368
inWidth = int(((aspect_ratio*inHeight)*8)//8)

vid_writer = cv2.VideoWriter('output.avi',cv2.VideoWriter_fourcc('M','J','P','G'), 15, (frame.shape[1],frame.shape[0]))

net = cv2.dnn.readNetFromCaffe(protoFile, weightsFile)
k = 0
while 1:
    x = []
    y = []
    k+=1
    #print(k)
    t = time.time()
    hasFrame, frame = cap.read()
    frameCopy = np.copy(frame)
    if not hasFrame:
        cv2.waitKey()
        break

    inpBlob = cv2.dnn.blobFromImage(frame, 1.0 / 255, (inWidth, inHeight),
                              (0, 0, 0), swapRB=False, crop=False)

    net.setInput(inpBlob)

    output = net.forward()

    print("forward = {}".format(time.time() - t))

    # Empty list to store the detected keypoints
    points = []



    for i in range(nPoints):
        # confidence map of corresponding body's part.
        probMap = output[0, i, :, :]
        probMap = cv2.resize(probMap, (frameWidth, frameHeight))

        # Find global maxima of the probMap.
        minVal, prob, minLoc, point = cv2.minMaxLoc(probMap)

        if prob > threshold :
            cv2.circle(frameCopy, (int(point[0]), int(point[1])), 6, (0, 255, 255), thickness=-1, lineType=cv2.FILLED)
            cv2.putText(frameCopy, "{}".format(i), (int(point[0]), int(point[1])), cv2.FONT_HERSHEY_SIMPLEX, .8, (0, 0, 255), 2, lineType=cv2.LINE_AA)

            # Add the point to the list if the probability is greater than the threshold
            points.append((int(point[0]), int(point[1])))
        else :
            points.append(None)

    fig = plt.figure()
    ax = fig.add_subplot(111)


    print(points)

    handkeypoints.append(points)
    #print(handkeypoints)
    print(np.shape(handkeypoints))

    # Draw Skeleton
    for pair in POSE_PAIRS:
        partA = pair[0]
        partB = pair[1]

        if points[partA] and points[partB]:
            cv2.line(frame, points[partA], points[partB], (0, 255, 255), 2, lineType=cv2.LINE_AA)
            cv2.circle(frame, points[partA], 5, (0, 0, 255), thickness=-1, lineType=cv2.FILLED)
            cv2.circle(frame, points[partB], 5, (0, 0, 255), thickness=-1, lineType=cv2.FILLED)

    print("Time Taken for frame = {}".format(time.time() - t))



    # cv2.putText(frame, "time taken = {:.2f} sec".format(time.time() - t), (50, 50), cv2.FONT_HERSHEY_COMPLEX, .8, (255, 50, 0), 2, lineType=cv2.LINE_AA)
    # cv2.putText(frame, "Hand Pose using OpenCV", (50, 50), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 50, 0), 2, lineType=cv2.LINE_AA)
    cv2.imshow('Output-Skeleton', frame)
    # cv2.imwrite("video_output/{:03d}.jpg".format(k), frame)
    key = cv2.waitKey(1)
    if key == 27:
        break

    print("total = {}".format(time.time() - t))

    vid_writer.write(frame)


    ##solve for fingertip 3d

    handKeypoints = points
    for i in range(len(handKeypoints)):
        if handKeypoints[i] == None:
            break
        if points.count(None) > 1:
            break
        x = np.append(x, handKeypoints[i][0])
        y = np.append(y, handKeypoints[i][1])
        i = i + 1
    if points.count(None) > 1:
        continue
    y_offset = max(y)
    x = 0.8 * x  # 0.5
    y = 0.7 * (-y + y_offset)  # 0.5

    plt.scatter(x, y)


    #plot thumb
    x_thumb = x[0:5]
    y_thumb = y[0:5]
    plt.plot(x_thumb, y_thumb, label='thumb')

    # plot index
    x_index = x[0]
    x_index = np.append(x_index, x[5:9])
    y_index = y[0]
    y_index = np.append(y_index, y[5:9])
    plt.plot(x_index, y_index, label='index')

    # plot middle
    x_middle = x[0]
    x_middle = np.append(x_middle, x[9:13])
    y_middle = y[0]
    y_middle = np.append(y_middle, y[9:13])
    plt.plot(x_middle, y_middle, label='middle')

    # plot ring
    x_ring = x[0]
    x_ring = np.append(x_ring, x[13:17])
    y_ring = y[0]
    y_ring = np.append(y_ring, y[13:17])
    plt.plot(x_ring, y_ring, label='ring')

    # plot pinky
    x_pinky = x[0]
    x_pinky = np.append(x_pinky, x[17:21])
    y_pinky = y[0]
    y_pinky = np.append(y_pinky, y[17:21])
    plt.plot(x_pinky, y_pinky, label='pinky')

    plt.title("Hand Keypoint Detection (Scaled)")
    plt.xlabel("x [mm]")
    plt.ylabel("z [mm]")
    ax.set_aspect(1)
    plt.legend()
    # plt.show()

    # set joints relative to finger origin
    y_thumb_j1 = y_thumb[2] - y_thumb[1]
    y_thumb_j2 = y_thumb[3] - y_thumb[2]

    y_index_j1 = y_index[2] - y_index[1]
    y_index_j2 = y_index[3] - y_index[2]
    y_index_j3 = y_index[4] - y_index[3]
    # print(y_index)
    a = np.array((x[6], y[6]))
    b = np.array((x[5], y[5]))
    dist = np.linalg.norm(a - b)
    # print(a,b)
    # print(dist)

    y_middle_j1 = y_middle[2] - y_middle[1]
    y_middle_j2 = y_middle[3] - y_middle[2]
    y_middle_j3 = y_middle[4] - y_middle[3]

    y_ring_j1 = y_ring[2] - y_ring[1]
    y_ring_j2 = y_ring[3] - y_ring[2]
    y_ring_j3 = y_ring[4] - y_ring[3]

    y_pinky_j1 = y_pinky[2] - y_pinky[1]
    y_pinky_j2 = y_pinky[3] - y_pinky[2]
    y_pinky_j3 = y_pinky[4] - y_pinky[3]

    ## solve thumb fingertip
    theta1_thumb = np.arcsin(y_thumb_j1 / l1)
    x_thumb_j1 = l1_thumb * np.cos(theta1_thumb)

    theta2_thumb = np.arcsin(y_thumb_j2 / l2)
    x_thumb_j2 = x_thumb_j1 + l2_thumb * np.cos(theta2_thumb)

    x_dist_thumb = abs(x_thumb[4] - x_thumb[2])

    thumb_fingertip = [x_dist_thumb, x_thumb_j2, y_thumb[4] - y_thumb[2]]
    thumb_fingertip = list(np.around(np.array(thumb_fingertip), 2))

    thumb_joint = [np.degrees(theta1_thumb), np.degrees(theta2_thumb)]
    thumb_joint = list(np.around(np.array(thumb_joint), 2))

    ##solve index fingertip
    theta1_index = np.arcsin(y_index_j1 / l1)
    x_index_j1 = l1 * np.cos(theta1_index)
    # print(x_index_j1)

    theta2_index = np.arcsin(y_index_j2 / l2)
    x_index_j2 = x_index_j1 + l2 * np.cos(theta2_index)
    # print(x_index_j2)

    theta3_index = np.arcsin(y_index_j3 / l3)
    x_index_j3 = x_index_j2 + l3 * np.cos(theta3_index)
    # print(x_index_j3)

    index_fingertip = [0, x_index_j3, y_index[4] - y_index[1]]
    index_fingertip = list(np.around(np.array(index_fingertip), 2))

    index_joint = [np.degrees(theta1_index), np.degrees(theta2_index), np.degrees(theta3_index)]
    index_joint = list(np.around(np.array(index_joint), 2))

    ##solve middle fingertip
    theta1_middle = np.arcsin(y_middle_j1 / l1)
    x_middle_j1 = l1 * np.cos(theta1_middle)
    # print(x_middle_j1)

    theta2_middle = np.arcsin(y_middle_j2 / l2)
    x_middle_j2 = x_middle_j1 + l2 * np.cos(theta2_middle)
    # print(x_middle_j2)

    theta3_middle = np.arcsin(y_middle_j3 / l3)
    x_middle_j3 = x_middle_j2 + l3 * np.cos(theta3_middle)
    # print(x_middle_j3)

    middle_fingertip = [0, x_middle_j3, y_middle[4] - y_middle[1]]
    middle_fingertip = list(np.around(np.array(middle_fingertip), 2))

    middle_joint = [np.degrees(theta1_middle), np.degrees(theta2_middle), np.degrees(theta3_middle)]
    middle_joint = list(np.around(np.array(middle_joint), 2))

    ##solve ring fingertip
    theta1_ring = np.arcsin(y_ring_j1 / l1)
    x_ring_j1 = l1 * np.cos(theta1_ring)
    # print(x_ring_j1)

    theta2_ring = np.arcsin(y_ring_j2 / l2)
    x_ring_j2 = x_ring_j1 + l2 * np.cos(theta2_ring)
    # print(x_ring_j2)

    theta3_ring = np.arcsin(y_ring_j3 / l3)
    x_ring_j3 = x_ring_j2 + l3 * np.cos(theta3_ring)
    # print(x_ring_j3)

    ring_fingertip = [0, x_ring_j3, y_ring[4] - y_ring[1]]
    ring_fingertip = list(np.around(np.array(ring_fingertip), 2))

    ring_joint = [np.degrees(theta1_ring), np.degrees(theta2_ring), np.degrees(theta3_ring)]
    ring_joint = list(np.around(np.array(ring_joint), 2))

    ##solve pinky fingertip
    theta1_pinky = np.arcsin(y_pinky_j1 / l1)
    x_pinky_j1 = l1 * np.cos(theta1_pinky)
    # print(x_pinky_j1)

    theta2_pinky = np.arcsin(y_pinky_j2 / l2)
    x_pinky_j2 = x_pinky_j1 + l2 * np.cos(theta2_pinky)
    # print(x_ring_j2)

    theta3_pinky = np.arcsin(y_pinky_j3 / l3)
    x_pinky_j3 = x_pinky_j2 + l3 * np.cos(theta3_pinky)
    # print(x_pinky_j3)

    pinky_fingertip = [0, x_pinky_j3, y_pinky[4] - y_pinky[1]]
    pinky_fingertip = list(np.around(np.array(pinky_fingertip), 2))

    pinky_joint = [np.degrees(theta1_pinky), np.degrees(theta2_pinky), np.degrees(theta3_pinky)]
    pinky_joint = list(np.around(np.array(pinky_joint), 2))

    if x_thumb[3] - x_thumb[2] > 0:
        thumb_fingertip0 = -thumb_fingertip[0]
    else:
        thumb_fingertip0 = thumb_fingertip[0]

    yscale_index = 0.6  # 0.3
    yscale_middle = 0.7  # 0.3
    yscale_ring = 0.6  # 0.3
    yscale_pinky = 0.5  # 0.3
    zscale = 1  # 1.4

    # calculated fingertip positions
    print("thumb fingertip position: [%.2f, %.2f, %.2f]" % (
    thumb_fingertip0, yscale_index * thumb_fingertip[1], zscale * thumb_fingertip[2]))
    print("index fingertip position: [%.2f, %.2f, %.2f]" % (
    10, yscale_index * index_fingertip[1], zscale * index_fingertip[2]))
    print("middle fingertip position: [%.2f, %.2f, %.2f]" % (
    20, yscale_middle * middle_fingertip[1], zscale * middle_fingertip[2]))
    print("ring fingertip position: [%.2f, %.2f, %.2f]" % (
    30, yscale_ring * ring_fingertip[1], zscale * ring_fingertip[2]))
    print("pinky fingertip position: [%.2f, %.2f, %.2f]" % (
    40, yscale_pinky * pinky_fingertip[1], zscale * pinky_fingertip[2]))
    print()

    fig = plt.figure(figsize=(4, 4))
    ax = fig.add_subplot(111, projection='3d')
    ax.scatter(-thumb_fingertip0, yscale_index * thumb_fingertip[1], zscale * thumb_fingertip[2], label='thumb')
    ax.scatter(-10, yscale_index * index_fingertip[1], zscale * index_fingertip[2], label='index')
    ax.scatter(-20, yscale_middle * middle_fingertip[1], zscale * middle_fingertip[2], label='middle')
    ax.scatter(-30, yscale_ring * ring_fingertip[1], zscale * ring_fingertip[2], label='ring')
    ax.scatter(-40, yscale_pinky * pinky_fingertip[1], zscale * pinky_fingertip[2], label='pinky')
    ax.set_xlabel('x (finger spacing) [mm]')
    ax.set_ylabel('y (finger reach) [mm]')
    ax.set_zlabel('z (finger height) [mm]')
    ax.legend()
    plt.title("Fingertip positions in 3D")
    plt.show()


#with open ('handkeypoints.txt', 'wb') as f:
#    pickle.dump(handkeypoints,f)

vid_writer.release()
